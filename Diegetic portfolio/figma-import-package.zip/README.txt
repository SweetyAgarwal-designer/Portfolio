Figma Import Package

Use this folder with a code-to-Figma plugin such as html.to.design.

Recommended workflow:
1. Zip this entire folder.
2. Open the plugin in Figma.
3. Use the File tab and upload the zip.
4. Import the generated frames and then turn repeated UI into Figma components.

Package notes:
- index.html is a static import board, not the live interactive website.
- styles.css is simplified for cleaner import.
- assets/gallery contains the local photography images used by the gallery frame.
- Remote project cover images are referenced directly from Behance CDN for the works and case-study frames.
